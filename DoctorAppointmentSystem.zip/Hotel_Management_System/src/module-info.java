/**
 * 
 */
/**
 * 
 */
module JAVA_PROJECTS {
	requires java.sql;
}